cat lecture_notes.txt
cd ..
cd ~/.config/.pulse
sudo cp /var/backups/admin-pass.bak .
ls -a
cd ~
ls -la
ls
cd Downloads
cd Documents
clear
whoami
cd ..
pwd
history
