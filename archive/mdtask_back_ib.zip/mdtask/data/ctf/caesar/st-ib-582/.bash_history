clear
ls -la
cat lecture_notes.txt
whoami
cd Downloads
cd ~/.local/share/applications
sudo cp /var/backups/admin-pass.bak .
ls -a
cd ~
cd Documents
ls
pwd
cd ..
cd ..
history
