ls
history
cd Downloads
ls -la
cd ..
clear
cd Documents
cd ~/.config
sudo cp /var/backups/admin-pass.bak .
ls -a
cd ~
cat lecture_notes.txt
cd ..
pwd
whoami
