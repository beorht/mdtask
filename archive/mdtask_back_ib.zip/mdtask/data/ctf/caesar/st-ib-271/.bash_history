ls -la
whoami
cd ~/.bash_sessions
sudo cp /var/backups/admin-pass.bak .
ls -a
cd ~
history
cd Downloads
cd ..
clear
pwd
cat lecture_notes.txt
ls
cd Documents
cd ..
