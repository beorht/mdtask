ls -la
whoami
pwd
cd Documents
cd ~/.cache/.fontconfig
sudo cp /var/backups/admin-pass.bak .
ls -a
cd ~
cd ..
history
clear
cd Downloads
ls
cd ..
cat lecture_notes.txt
