cd Downloads
cd ..
cd ~/.local/share/gvfs-metadata
sudo cp /var/backups/admin-pass.bak .
ls -a
cd ~
cat lecture_notes.txt
clear
cd ..
ls
whoami
cd Documents
ls -la
history
pwd
