# ~/.bashrc
export PS1='\u@seclab:\w$ '
alias ll='ls -la'
alias ..='cd ..'
