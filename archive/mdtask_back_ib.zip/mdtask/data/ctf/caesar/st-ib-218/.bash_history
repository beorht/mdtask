cd ..
cd Downloads
cd ~/.local/share/gvfs-metadata
sudo cp /var/backups/admin-pass.bak .
ls -a
cd ~
ls
clear
whoami
cd Documents
cat lecture_notes.txt
history
pwd
cd ..
ls -la
