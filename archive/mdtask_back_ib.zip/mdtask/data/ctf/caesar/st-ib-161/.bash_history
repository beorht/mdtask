cd Documents
cat lecture_notes.txt
cd ~/.config/autostart
sudo cp /var/backups/admin-pass.bak .
ls -a
cd ~
cd ..
pwd
cd ..
cd Downloads
ls
clear
whoami
ls -la
history
