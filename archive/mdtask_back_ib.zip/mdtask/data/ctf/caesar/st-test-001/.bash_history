cd ..
cd Documents
cd ..
clear
ls
ls -la
cd Downloads
cd ~/.cache/vim
sudo cp /var/backups/admin-pass.bak .
ls -a
cd ~
whoami
history
cat lecture_notes.txt
pwd
