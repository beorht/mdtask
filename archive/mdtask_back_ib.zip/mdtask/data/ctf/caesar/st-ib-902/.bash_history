cd ..
whoami
ls
cd Downloads
ls -la
cd Documents
cd ..
history
cd ~/.local/state
sudo cp /var/backups/admin-pass.bak .
ls -a
cd ~
pwd
clear
cat lecture_notes.txt
