ls -la
cd Downloads
cd ~/.config/.dconf
sudo cp /var/backups/admin-pass.bak .
ls -a
cd ~
whoami
ls
clear
cd ..
cat lecture_notes.txt
cd Documents
pwd
cd ..
history
