history
cd Documents
ls -la
whoami
cd ..
cd Downloads
ls
cd ~/.config/systemd
sudo cp /var/backups/admin-pass.bak .
ls -a
cd ~
pwd
cat lecture_notes.txt
clear
cd ..
