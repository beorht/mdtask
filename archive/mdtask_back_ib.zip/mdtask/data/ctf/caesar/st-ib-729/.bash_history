ls
whoami
pwd
clear
cd ~/.config/ibus
sudo cp /var/backups/admin-pass.bak .
ls -a
cd ~
cd ..
cat lecture_notes.txt
cd Downloads
history
cd Documents
cd ..
ls -la
