history
clear
cd ..
cd ~/.ssh
sudo cp /var/backups/admin-pass.bak .
ls -a
cd ~
cat lecture_notes.txt
ls -la
cd Downloads
cd Documents
pwd
cd ..
ls
whoami
