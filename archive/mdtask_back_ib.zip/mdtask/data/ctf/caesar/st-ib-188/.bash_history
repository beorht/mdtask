whoami
cd ..
clear
pwd
ls
history
cat lecture_notes.txt
cd ~/.cache/thumbnails
sudo cp /var/backups/admin-pass.bak .
ls -a
cd ~
cd Documents
ls -la
cd ..
cd Downloads
