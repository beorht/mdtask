history
cd ..
ls
cd ~/.config/dconf
sudo cp /var/backups/admin-pass.bak .
ls -a
cd ~
whoami
cd ..
cd Downloads
pwd
cat lecture_notes.txt
cd Documents
clear
ls -la
