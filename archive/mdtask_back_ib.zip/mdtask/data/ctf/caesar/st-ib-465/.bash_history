cat lecture_notes.txt
whoami
cd ..
cd ~/.local/state
sudo cp /var/backups/admin-pass.bak .
ls -a
cd ~
ls -la
cd ..
history
cd Downloads
cd Documents
pwd
clear
ls
