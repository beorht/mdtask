clear
pwd
cat lecture_notes.txt
cd ..
ls -la
cd ~/.ssh
sudo cp /var/backups/admin-pass.bak .
ls -a
cd ~
history
whoami
cd Downloads
cd Documents
ls
cd ..
