history
cd Downloads
whoami
pwd
cd Documents
ls
cd ~/.local/share/keyrings
sudo cp /var/backups/admin-pass.bak .
ls -a
cd ~
cat lecture_notes.txt
cd ..
cd ..
clear
ls -la
