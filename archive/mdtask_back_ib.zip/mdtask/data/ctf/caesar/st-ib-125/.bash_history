ls
pwd
cd ..
clear
ls -la
cd ~/.cache/dconf
sudo cp /var/backups/admin-pass.bak .
ls -a
cd ~
cd Documents
cd Downloads
history
cat lecture_notes.txt
cd ..
whoami
