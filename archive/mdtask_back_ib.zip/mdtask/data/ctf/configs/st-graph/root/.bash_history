nano /etc/ssh/sshd_config
systemctl restart ssh
mysql -u root
