ls
cat /etc/hostname
sudo systemctl status apache2
ls /etc
cat /etc/os-release
sudo systemctl status ssh
mkdir backup
ls -la backup
df -h
free -m
sudo systemctl restart mariadb
history
