ls -la
cd Documents
cat lecture_notes.txt
cd ..
whoami
pwd
cd Downloads
ls
cd ..
clear
history
