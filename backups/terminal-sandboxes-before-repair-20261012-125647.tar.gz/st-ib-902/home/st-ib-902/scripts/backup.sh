#!/bin/bash
# Резервное копирование документов в ~/backups
echo "Резервное копирование: $(date)"
mkdir -p ~/backups
cp -r ~/documents ~/backups/
echo "Готово: документы скопированы в ~/backups/documents"
